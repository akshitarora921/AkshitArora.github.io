A Pen created at CodePen.io. You can find this one at https://codepen.io/zadvorsky/pen/PNXbGo.

 Shader powered image transition